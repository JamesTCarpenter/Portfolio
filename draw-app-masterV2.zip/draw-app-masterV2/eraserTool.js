function EraserTool(){
    this.icon = "assets/eraser.jpg";
    this.name = "eraser";
}